# Mod Menu (Fabric 1.21.4)

Jedno menu na wszystko. Domyślny klawisz: **Prawy Shift** (zmienisz w Sterowanie -> Mod Menu).

## Co jest w modzie
- **Wygląd**: zaokrąglone GUI, logo, ikony po lewej z nazwami i kolorowe "szkło", które płynnie przelatuje do klikniętej zakładki.
- **Gracze**: lista osób w zasięgu, odległość, znacznik CHUNK.
- **Ustawienia**: kolor GUI (picker, zapis po "Gotowe"), zaokrąglone ramki, dźwięki, **cień za tekstem** (wł./wył.),
  **motyw**: Ciemny / Jasny / Podstawowy, bind klawisza dla "Brak cieni".
  Przełączniki mają stały kolor (zielony), więc nie zlewają się z kolorem GUI.
- **Mody** (karta + zębatka = ustawienia danego modu, z animacją przejścia):
  - **Brak cieni**: wyłącz wszystko / tylko cienie bytów / tylko cienie bloków, z podglądem.
  - **Brak animacji wyciągania**: przedmiot w ręce pojawia się od razu.
  - **HUD**: XYZ, facing, fps, ping, tps. W ustawieniach HUD-a wybierasz elementy i klikasz **Przesuń HUD**,
    potem przeciągasz HUD myszką, gdzie chcesz, i klikasz Gotowe.
- **Profil**: głowa, nick, czas sesji, wykres czasu gry z 7 dni, **tagi** (klik "+" i wpisz, Enter zatwierdza,
  klik w tag usuwa; do 6 tagów po 12 znaków).

## Instalacja
1. Skopiuj `src` z paczki do repo (nadpisz pliki), commit + push na `main`.
2. GitHub: Actions -> build -> Run workflow -> Artifacts -> jar.
3. `.jar` do `.minecraft/mods` razem z Fabric API 1.21.4.

## Uwagi
- Nie mam jak skompilować tego tutaj. Jeśli build się wysypie, wklej błąd z Actions.
  Najbardziej podejrzane: `PlayerSkinDrawer.draw(...)`, `SoundEvent.of(...)`, `HudRenderCallback`, pola w `HeldItemRendererMixin`.
- "tps" w HUD pokazuje tempo ticków świata po stronie klienta (zwykle 20), a nie prawdziwe TPS serwera.
- "Brak cieni" może nie działać z Sodium i podobnymi modami zmieniającymi renderer.
